clc
close all
clear all
%% === PARAMETRI (Aggiunto hcg e Anti-Squat/Dive) ===
syms m kf kr betaf betar ell0 g df dr J mwf mwr ktf ktr hcg gammaf gammar real
% Vettore parametri aggiornato (17 parametri)
vars = [m, kf, kr, betaf, betar, ell0, g, df, dr, J, mwf, mwr, ktf, ktr, hcg, gammaf, gammar]; 
%% Variabili di stato, input e disturbo
syms pz vz ptheta vtheta hwheelf dhwheelf hwheelr dhwheelr real
syms thetaroad_f zroad_f thetaroad_r zroad_r real
syms u1 u2 real 
syms zroad_f_dot zroad_r_dot alphag_f alphag_r fwfront fwrear real 
syms nuy nug nuz nuf nur rz rtheta real             
%% === CONDIZIONI DI EQUILIBRIO ===
Delta0 = -(m)*g/(kf+kr);           
Delta0_W = -(m+mwf+mwr)*g/(2*ktf); 
%% Cinematiche e Forze
s1 = (pz + df * sin(ptheta)) - hwheelf; 
s3 = (pz - dr * sin(ptheta)) - hwheelr;
s2 = vz + df * vtheta * cos(ptheta) - dhwheelf;
s4 = vz - dr * vtheta * cos(ptheta) - dhwheelr;
fsf = -kf*s1 - betaf*s2;      
fsr = -kr*s3 - betar*s4;      

% Componenti verticali indotte dalla geometria (Anti-Dive / Anti-Squat)
F_vert_long_f = gammaf * fwfront;
F_vert_long_r = gammar * fwrear;

ftf =  ktf*(zroad_f - hwheelf); 
ftr =  ktr*(zroad_r - hwheelr); 
fmgf = - mwf * g;
fmgr = - mwr * g;
Fxf = fwfront; 
Fxr = fwrear;
F_tot_x = Fxf + Fxr;
%% Dinamica: Attuatori e Corpo
faf = ( dr*u1 + u2) / (df + dr);
far = ( df*u1 - u2) / (df + dr);
% Acc. verticale (z_ddot) - Include le forze indotte longitudinali
f2 = -g + (fsf + fsr + faf + far + F_vert_long_f + F_vert_long_r)/m;
% Acc. angolare (theta_ddot) - Include hcg e il contributo asimmetrico di F_vert_long
f4 = (df*(fsf + faf + F_vert_long_f) - dr*(fsr + far + F_vert_long_r) + F_tot_x * hcg) / J;      
%% Dinamica: Ruote
f_wf = (ftf - fsf - faf - F_vert_long_f + fmgf)/mwf;   
f_wr = (ftr - fsr - far - F_vert_long_r + fmgr)/mwr;
% Vettore f (dx/dt) - 12 Stati
f_sys = [vz; f2; vtheta; f4; dhwheelf; f_wf; dhwheelr; f_wr; ...
         alphag_f; alphag_r; zroad_f_dot; zroad_r_dot];
%% Output
ax = F_tot_x / m; 
az_rel = f2 + g; 
y = [sin(ptheta)*(az_rel) + cos(ptheta)*(ax) + nuy; 
     cos(ptheta)*(az_rel) - sin(ptheta)*(ax) + nuz; 
     vtheta + nug;                                  
     s1 + nuf;                                      
     s3 + nur];                                     
%% Errori
e = [((s1+nuf)*dr + (s3+nur)*df)/(dr + df) - rz; 
     ptheta - rtheta]; 
%% Linearizzazione simbolica
states = [pz, vz, ptheta, vtheta, hwheelf, dhwheelf, hwheelr, dhwheelr, ...
          thetaroad_f, thetaroad_r, zroad_f, zroad_r];
inputs1 = [u1, u2]; 
inputs2 = [zroad_f_dot, zroad_r_dot, alphag_f, alphag_r, fwfront, fwrear];
disturb_vars = [zroad_f_dot, zroad_r_dot, alphag_f, alphag_r, fwfront, fwrear, ...
                nuy, nuz, nug, nuf, nur, rz, rtheta];

A   = jacobian(f_sys, states);
B1  = jacobian(f_sys, inputs1);
B2  = jacobian(f_sys, inputs2);
C   = jacobian(y, states);
D1  = jacobian(y, inputs1);
D2  = jacobian(y, disturb_vars);
CE  = jacobian(e, states);
DE1 = jacobian(e, inputs1);
DE2 = jacobian(e, disturb_vars);

% Stampe simboliche
disp('Matrice A (12x12):'); disp(A);
disp('Matrice B1 (12x2):'); disp(B1);
disp('Matrice B2 (12x5):'); disp(B2);
disp('Matrice C (5x12):'); disp(C);
disp('Matrice D1 (5x2):'); disp(D1);
disp('Matrice D2 (5x12):'); disp(D2);
disp('Matrice CE (2x12):'); disp(CE);
disp('Matrice DE1 (2x2):'); disp(DE1);
disp('Matrice DE2 (2x12):'); disp(DE2);

% % Valori numerici dei parametri
% m    = 2500;      
% kf   = 41000;     
% kr   = 29000;     
% betaf = 4500;     
% betar = 4500;     
% ell0 = 0.5;      
% g    = 9.81;     
% df   = 1.4;        
% dr   = 1.9;        
% J    = (( m * (df + dr)^2 ) / 12 ) * 2.4;      
% mwf  = 45;       
% mwr  = 45;       
% ktf  = 280000;   
% ktr  = 280000;   
% hcg  = 0.55;     
% gammaf = 0.05;    % 5% Anti-Dive
% gammar = 0.08;    % 8% Anti-Squat

% --- Valori numerici per Rolls-Royce (Modello Half-Car) ---
m      = 2550;     % [kg] Massa carrozzeria (veicolo generoso)
g      = 9.81;     % [m/s^2]
hcg    = 0.60;     % [m] Centro di gravità più alto rispetto a una sportiva

% Geometria e Distribuzione Pesi
df     = 1.65;     % [m] CG -> asse anteriore
dr     = 1.65;     % [m] CG -> asse posteriore (distribuzione ~50/50)
L      = df + dr;  % [m] Passo totale (circa 3.3m)

% Inerzia in pitch (Formula dinamica)
% Utilizziamo J = m * (k_p)^2 dove k_p è il raggio di girazione.
% Per berline di lusso, k_p è circa il 35-40% del passo.
J      = m * (0.38 * L)^2; 

% Sospensioni (Taratura "Magic Carpet Ride")
kf     = 35000;    % [N/m] Molto morbida per isolamento
kr     = 32000;    % [N/m] 
betaf  = 4200;     % [N*s/m] Smorzamento controllato elettronicamente
betar  = 4200;     

% Masse non sospese e Pneumatici (Ruote grandi e pesanti)
mwf    = 48;       % [kg]
mwr    = 48;       
ktf    = 270000;   % [N/m] Rigidezza pneumatico (alto profilo)
ktr    = 270000;   

% Geometria Anti-Pitch
gammaf = 0.05;     % 5% Anti-Dive (minimo, privilegia il comfort)
gammar = 0.08;     % 8% Anti-Squat
ell0   = 0.55;     % [m] Altezza statica potenziometro

par_numeric = [m, kf, kr, betaf, betar, ell0, g, df, dr, J, mwf, mwr, ktf, ktr, hcg, gammaf, gammar]; 
vehicle_speed = 20;
rear_bump_time_delay = (df + dr) / vehicle_speed; 

%% initial conditions
x0_lin = zeros(12,1);
Delta0_num = -(m)*g/(kf+kr);           
Delta0_W_num = -(m+mwf*2)*g/(2*ktf); 
x0 = [Delta0_num + Delta0_W_num; 0; 0; 0; Delta0_W_num; 0; Delta0_W_num; 0];
u0 = [0; 0];
linear_point = states;
linear_value = [Delta0_num + Delta0_W_num, 0, 0, 0, Delta0_W_num, 0, Delta0_W_num, 0, 0, 0, 0, 0];

% Sostituzione numerica
A_0   = subs(A,   [linear_point, fwrear, fwfront, u1, u2], [linear_value, 0, 0, u0(1), u0(2)]);
B1_0  = vpa(subs(B1,  [linear_point, u1, u2], [linear_value, u0(1), u0(2)]), 6);
B2_0  = vpa(subs(B2,  [pz, ptheta, hwheelf, hwheelr, zroad_f, zroad_r, thetaroad_f, thetaroad_r], ...
                      [Delta0_num + Delta0_W_num, 0, Delta0_W_num, Delta0_W_num, 0, 0, 0, 0]), 6);
C_0   = vpa(subs(C,   [linear_point, fwrear, fwfront, u1, u2, alphag_f, alphag_r], [linear_value, 0, 0, u0(1), u0(2), 0, 0]), 6);
D1_0  = vpa(subs(D1,  [linear_point, u1, u2], [linear_value, u0(1), u0(2)]), 6);
D2_0  = subs(D2,  linear_point, linear_value);
CE_0  = vpa(simplify(subs(CE,  [linear_point, disturb_vars, u1, u2], [linear_value, disturb_vars, u0(1), u0(2)])), 6);
DE1_0 = vpa(simplify(subs(DE1, [linear_point, disturb_vars], [linear_value, disturb_vars])), 6);
DE2_0 = vpa(simplify(subs(DE2, [linear_point, disturb_vars, u1, u2], [linear_value, disturb_vars,u0(1), u0(2)])), 6);

disp('Matrice numerica A_0:'); disp(A_0);

%% Conversione double
symbol_vars = num2cell(vars);
numeric_vals = num2cell(par_numeric);

A_N = double(vpa(subs(A_0, symbol_vars , numeric_vals), 6));
B1_N = double(vpa(subs(B1_0, symbol_vars , numeric_vals), 6));
B2_N = double(vpa(subs(B2_0, symbol_vars , numeric_vals), 6));
C_N = double(vpa(subs(C_0, symbol_vars , numeric_vals), 6));
D1_N = double(vpa(subs(D1_0, symbol_vars , numeric_vals), 6));
D2_N = double(vpa(subs(D2_0, symbol_vars , numeric_vals), 6));
CE_N = double(vpa(subs(CE_0, symbol_vars , numeric_vals), 6));
DE1_N = double(vpa(subs(DE1_0, symbol_vars , numeric_vals), 6));
DE2_N = double(vpa(subs(DE2_0, symbol_vars , numeric_vals), 6));

disp('Matrice numerica A (12x12):'); disp(A_N);

%% === OSSERVATORE DI KALMAN (Per i 12 stati fisici) ===

% L'osservatore stima solo gli stati fisici (x), non gli integrali.
% Usiamo LQR (Duality Principle) per trovare il guadagno ottimo Ko.

% Parametri di tuning per l'Osservatore
% Aumenta Q_kalman se vuoi che l'osservatore sia più veloce (si fida dei sensori)
% Aumenta R_kalman se i sensori sono molto rumorosi (si fida del modello)
Q_kalman = eye(12) * 1e6; 
R_kalman = eye(5)  * 1e-3; 

% Per garantire la stabilità numerica, usiamo una piccola regolarizzazione
A_reg = A_N - 1e-6 * eye(12);

% Calcolo del guadagno Ko (Trasposto perché è il duale del controllo)
Ko = lqr(A_reg', C_N', Q_kalman, R_kalman)';

disp('=== Osservatore Ko calcolato ===');
disp(['Dimensione Ko: ', num2str(size(Ko,1)), 'x', num2str(size(Ko,2))]);

%% === AGGIORNAMENTO CONTROLLI (Versione Integrale + Derivativa) ===

% --- Parametri di Tuning (Modifica questi per vedere gli effetti) ---
weight_P = 1.0;   % Reattività (Azione Proporzionale)
weight_D = 2.0;   % Smorzamento (Azione Derivativa)
weight_I = 0.005;   % Precisione (Azione Integrale)

% Definizione dei pesi base
q_pz_base = 2e8;      q_vz_base = 8e5; 
q_ptheta_base = 3e9;  q_vtheta_base = 1e6;
q_unsprung = 1e2;
q_heave_int_base = 1e10; 
q_pitch_int_base = 5e11;

% Applicazione dei pesi per Q_aug
q_pz_P = q_pz_base * weight_P;
q_vz_D = q_vz_base * weight_D;
q_ptheta_P = q_ptheta_base * weight_P;
q_vtheta_D = q_vtheta_base * weight_D;
q_heave_int = q_heave_int_base * weight_I;
q_pitch_int = q_pitch_int_base * weight_I;

% 1. Selezioniamo solo gli stati CONTROLLABILI (primi 8 stati fisici)
A_ctrl = A_N(1:8, 1:8);
B_ctrl = B1_N(1:8, :);
CE_ctrl = CE_N(:, 1:8); 
DE1_ctrl = DE1_N;

% 2. Costruzione del Sistema Aumentato (10 stati: 8 fisici + 2 integrali)
A_aug = [ A_ctrl,               zeros(8, 2); 
          CE_ctrl,              zeros(2, 2) ];

B_aug = [ B_ctrl; 
          DE1_ctrl ];

% 3. Composizione Matrice Q_aug (10x10)
Q_aug = diag([q_pz_P, q_vz_D, q_ptheta_P, q_vtheta_D, ... 
              q_unsprung, q_unsprung, q_unsprung, q_unsprung, ...
              q_heave_int, q_pitch_int]);

R_aug = eye(2) * 0.1;

% 4. Calcolo Guadagno LQR (Stabilizzante)
Ks_aug_reduced = lqr(A_aug, B_aug, Q_aug, R_aug);

% 5. Ricostruzione per Simulink (Ks_prop 2x12 e Ks_int 2x2)
% Aggiungiamo 4 colonne di zeri per gli stati strada non controllabili
Ks_prop = [Ks_aug_reduced(:, 1:8), zeros(2, 4)]; 
Ks_int  = Ks_aug_reduced(:, 9:10);

disp('Controllo PID-LQR calcolato correttamente con pesi pesati.');


%% === MATRICI SPECIFICHE PER SISTEMA NON LINEARE (8 STATI) ===

% 1. Matrice Guadagno Controllo (P+D) per 8 stati
% Estraiamo le prime 8 colonne (che corrispondono agli 8 stati fisici) 
% delle 2 righe (che corrispondono ai 2 ingressi u1, u2)
Ks_nonlin_prop = Ks_prop(1:2, 1:8);

% Ks_aug_reduced è la matrice 2x10 (8 stati fisici + 2 integrali)
% Le ultime due colonne corrispondono ai guadagni degli stati integrali
Ks_nonlin_int = Ks_aug_reduced(:, 9:10); % Risultato: matrice 2x2

% 2. Matrice Guadagno Osservatore (Ko) per 8 stati
% Dobbiamo ricalcolare Ko solo per la parte fisica
A_nonlin = A_N(1:8, 1:8);
C_nonlin = C_N(:, 1:8); % Le uscite y dipendono dai primi 8 stati

Q_kal_nonlin = eye(8) * 1e6; 
R_kal_nonlin = eye(5) * 1e-3; 
Ko_nonlin = lqr(A_nonlin', C_nonlin', Q_kal_nonlin, R_kal_nonlin)';

% 3. Il guadagno Integrale (Ks_int) rimane lo stesso (2x2)
% Perché agisce sull'errore esterno, non sullo stato interno.